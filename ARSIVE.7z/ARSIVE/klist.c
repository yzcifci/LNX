LISTE YONETIMI
-------------------------------------------------------------------------------------------------------------
void klist_init(struct klist *k, void (*get)(struct klist_node *),
		void (*put)(struct klist_node *))
{
	INIT_LIST_HEAD(&k->k_list);
	static inline void INIT_LIST_HEAD(struct list_head *list)
	{
		WRITE_ONCE(list->next, list);
		WRITE_ONCE(list->prev, list);
	}
	spin_lock_init(&k->k_lock);
	k->get = get;
	k->put = put;
}
-------------------------------------------------------------------------------------------------------------
void klist_init(struct klist *k, void (*get)(struct klist_node *),
		void (*put)(struct klist_node *))
{
	***
	k->k_list->next=k_klist;
	k->k_list->prev=k_klist;
	k->get = get;
	k->put = put;
	***
}
-------------------------------------------------------------------------------------------------------------
static void klist_node_init(struct klist *k, struct klist_node *n)
{
	INIT_LIST_HEAD(&n->n_node);
		n->n_node->next = n->n_node;
		n->n_node->prev = n->n_node;
	kref_init(&n->n_ref);
		n->n_ref->refcount = 1;
	knode_set_klist(n, k);
		n->n_klist = k;
}
-------------------------------------------------------------------------------------------------------------
void klist_add_tail(struct klist_node *n, struct klist *k)
{
	klist_node_init(k, n);
		n->n_node->next = n->n_node;
		n->n_node->prev = n->n_node;
		n->n_ref->refcount = 1;
		n->n_klist = k;
	add_tail(k, n);
		__list_add(n->n_node, k->k_list->prev, k->k_list);
		ile k->k_list->prev ile k->k_list arasına n->n_node nodunu ekler
	
	struct klist_node *n nodunu init eder ve struct klist *k listesine ekler
}
-------------------------------------------------------------------------------------------------------------
struct klist 
{
	spinlock_t		k_lock;
	struct list_head	k_list;
	void			(*get)(struct klist_node *);
	void			(*put)(struct klist_node *);
} __attribute__ ((aligned (sizeof(void *))));
-------------------------------------------------------------------------------------------------------------
struct klist_node {
	void			*n_klist;	/* never access directly */ //assigned to &struct klist
	struct list_head	n_node;
	struct kref		n_ref;
};
-------------------------------------------------------------------------------------------------------------
static void add_tail(struct klist *k, struct klist_node *n)
{
	 __list_add(n->n_node, k->k_list->prev, k->k_list);
	 ile k->k_list->prev ile k->k_list arasına n->n_node nodunu ekler
}
-------------------------------------------------------------------------------------------------------------
static inline void list_add_tail(struct list_head *new, struct list_head *head)
{
	 __list_add(new, head->prev, head);
	 ile head->prev ile head arasına new nodunu ekler
}
-------------------------------------------------------------------------------------------------------------
static inline void __list_add(struct list_head *new,
			      struct list_head *prev,
			      struct list_head *next)
{
	prev nodu ile next nodu arasına new nodunu ekler
	next->prev = new;
	new->next = next;
	new->prev = prev;
	prev->next = new;
}
-------------------------------------------------------------------------------------------------------------
static inline void INIT_LIST_HEAD(struct list_head *list)
{
	list->next = list;
	list->prev = list;
}
static inline void kref_init(struct kref *kref)
{
	kref->refcount = 1;
}
static void knode_set_klist(struct klist_node *knode, struct klist *klist)
{
	knode->n_klist = klist;
}