struct driver_private {
	struct kobject kobj;
	struct klist klist_devices;
	struct klist_node knode_bus;
	struct module_kobject *mkobj;
	struct device_driver *driver;
};
-------------------------------------------------------------------------------------------------------------
struct device_driver {
	const char		*name;
	struct bus_type		*bus;

	struct module		*owner;
	const char		*mod_name;	/* used for built-in modules */

	bool suppress_bind_attrs;	/* disables bind/unbind via sysfs */
	enum probe_type probe_type;

	const struct of_device_id	*of_match_table;
	const struct acpi_device_id	*acpi_match_table;

	int (*probe) (struct device *dev);
	void (*sync_state)(struct device *dev);
	int (*remove) (struct device *dev);
	void (*shutdown) (struct device *dev);
	int (*suspend) (struct device *dev, pm_message_t state);
	int (*resume) (struct device *dev);
	const struct attribute_group **groups;
	const struct attribute_group **dev_groups;

	const struct dev_pm_ops *pm;
	void (*coredump) (struct device *dev);

	struct driver_private *p;
};



struct platform_driver omap_i2c_driver =
{
	int (*probe)(struct platform_device *)									= omap_i2c_probe;
	int (*remove)(struct platform_device *)									= omap_i2c_remove;	
	struct device_driver driver;		
	{		
		const char		*name;												= "omap_i2c"
		struct bus_type		*bus;		
		{		
			const char		*name;											= "platform"
			const struct attribute_group **dev_groups;						= platform_dev_groups
			int (*match)(struct device *dev, struct device_driver *drv);	= platform_match	
			int (*uevent)(struct device *dev, struct kobj_uevent_env *env);	= platform_uevent
			int (*probe)(struct device *dev);								= platform_probe
			void (*remove)(struct device *dev);								= platform_remove
			void (*shutdown)(struct device *dev);							= platform_shutdown
			int (*dma_configure)(struct device *dev);						= platform_dma_configure
			const struct dev_pm_ops *pm;									= &platform_dev_pm_ops
			struct subsys_private *p
			{
				struct kset *devices_kset;
				struct kset *drivers_kset;
				{
					struct list_head list;
					spinlock_t list_lock;
					struct kobject kobj;
					{
						const char		*name;
						struct list_head	entry;
						struct kobject		*parent;
						struct kset		*kset;
						struct kobj_type	*ktype;
						struct kref		kref;
					};
				} __randomize_layout;
				struct klist klist_devices; //(struct device*)
				struct klist klist_drivers;
				struct blocking_notifier_head bus_notifier;
				unsigned int drivers_autoprobe:1;
				struct bus_type *bus;

			};
		};
		struct driver_private *p
		{
			struct kobject kobj;// kseti  bus_add_driver() içerisinde = bus->p->drivers_kset atanır;
			struct klist klist_devices;
			struct klist_node knode_bus;
			struct module_kobject *mkobj;
			struct device_driver *driver;// = &struct device_driver driver assigned in bus_add_driver()
		};
	};
};
#if defined(CONFIG_MODULES=y) && defined(CONFIG_SYSFS=y)
-------------------------------------------------------------------------------------------------------------
int bus_add_driver(struct device_driver *drv)
{
	struct bus_type *bus;
	struct driver_private *priv;
	bus = drv->bus;
	priv = kzalloc(sizeof(*priv), GFP_KERNEL);
	
	klist_init((klist*)&priv->klist_devices, NULL, NULL);
		priv->klist_devices->k_list->next=priv->klist_devices->k_list;
		priv->klist_devices->k_list->prev=priv->klist_devices->k_lis;
		priv->klist_devices->get = NULL;
		priv->klist_devices->put = NULL;
	//struct driver_private *priv->struct klist klist_devices init edilir
	
	priv->driver = drv;
	drv->p = priv;
	priv->kobj.kset = bus->p->drivers_kset;
	
	error = kobject_init_and_add(&priv->kobj, &driver_ktype, NULL,
				     "%s", drv->name);
		priv->kobj->kref->refcount = 1;
		priv->kobj->entry->next = priv->kobj->entry;
		priv->kobj->entry->prev = priv->kobj->entry;
		priv->kobj->state_in_sysfs = 0;
		priv->kobj->state_add_uevent_sent = 0;
		priv->kobj->state_remove_uevent_sent = 0;
		priv->kobj->state_initialized = 1;
		priv->kobj->ktype = ktype;
		priv->kobj->name, "%s", drv->name const char *fmt, va_list vargs ile gelen formatla set edilir
		priv->kobj->parent = NULL; atanır
		kobject_add_internal(kobj); ile kobj_kset_join(struct kobject *kobj) çağrılarak
		priv->kobj->kset->list listesine priv->kobj->entry sini ekler
	//priv->kobj init edilir, ismi atanır kset kernel seti ne atanır, parentı atanır.
	
	klist_add_tail((struct klist_node*)&priv->knode_bus, (struct klist*)&bus->p->klist_drivers);
		klist_node_init(bus->p->klist_drivers, priv->knode_bus);
			priv->knode_bus->n_node->next = priv->knode_bus->n_node;
			priv->knode_bus->n_node->prev = priv->knode_bus->n_node;
			priv->knode_bus->n_ref->refcount = 1;
			priv->knode_bus->n_klist = bus->p->klist_drivers;
		add_tail(bus->p->klist_drivers, priv->knode_bus);
			__list_add(priv->knode_bus->n_node, bus->p->klist_drivers->k_list->prev, bus->p->klist_drivers->k_list);
			ile bus->p->klist_drivers->k_list->prev ile bus->p->klist_drivers->k_list arasına priv->knode_bus->n_node nodunu ekler
		
		struct klist_node *priv->knode_bus nodunu init eder ve struct klist *bus->p->klist_drivers listesine ekler
	//(struct klist*)&bus->p->klist_drivers klist listesine (struct klist_node*)&priv->knode_bus nodu eklenir
	
}