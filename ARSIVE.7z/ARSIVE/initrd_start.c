-initrd_start ve initrd_end addresleri eski kernellerde ATAG lar ile alınmaktadır.
 fakat yeni kernellerde bunlar device tree ile alınmaktadır.
 
start_kernel(void)
 void __init setup_arch(char **cmdline_p)
  const struct machine_desc * __init setup_machine_fdt(void *dt_virt)
   void __init early_init_dt_scan_nodes(void)
	int __init of_scan_flat_dt(int (*it)(unsigned long node, const char *uname, int depth, void *data)=early_init_dt_scan_chosen,  void *data=boot_command_line)
	 int __init early_init_dt_scan_chosen(unsigned long node, const char *uname, int depth, void *data)
	  static void __init early_init_dt_check_for_initrd(unsigned long node)
	   static void __early_init_dt_declare_initrd(unsigned long start, unsigned long end)
		{
			if (!IS_ENABLED(CONFIG_ARM64)) {
				initrd_start = (unsigned long)__va(start);
				initrd_end = (unsigned long)__va(end);
				initrd_below_start_ok = 1;
			}
		} 