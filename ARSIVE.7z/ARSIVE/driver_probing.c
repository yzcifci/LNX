struct platform_device 
{
	const char	*name;
	struct device	dev;
	{
		struct kobject kobj;
		struct device		*parent;
		struct device_private	*p;
		const char		*init_name; /* initial name of the device */
		const struct device_type *type;
		struct bus_type	*bus;		/* type of bus device is on */
		struct device_driver *driver;	/* which driver has allocated this device */
		void		*platform_data;	/* Platform specific data, device core doesn't touch it */
		void		*driver_data;	/* Driver data, set and get with*/
	}
};
---------------------------------------------------------------------------------------------------------------------
struct platform_driver sysc_driver 
{
	int (*probe)(struct platform_device *) = sysc_probe
	int (*remove)(struct platform_device *) = sysc_remove
	void (*shutdown)(struct platform_device *);
	int (*suspend)(struct platform_device *, pm_message_t state);
	int (*resume)(struct platform_device *);
	struct device_driver driver;
	{
		const char		*name = "ti-sysc",
		struct bus_type		*bus;
		struct module		*owner;
		const char		*mod_name;	/* used for built-in modules */
		const struct of_device_id	*of_match_table = sysc_match =
		{
			{ .compatible = "ti,sysc-omap2", .data = &sysc_omap2, },
			{ .compatible = "ti,sysc-omap2-timer", .data = &sysc_omap2_timer, },
			{ .compatible = "ti,sysc-omap4", .data = &sysc_omap4, },
			{ .compatible = "ti,sysc-omap4-timer", .data = &sysc_omap4_timer, }
			...
		}
		int (*probe) (struct device *dev);
		struct driver_private *p;
	};

	const struct platform_device_id *id_table;
	bool prevent_deferred_probe;
};
---------------------------------------------------------------------------------------------------------------------
struct sysc 
{
	struct device *dev; 
	{
		struct kobject kobj;
		struct device		*parent;
		struct device_private	*p;
		const struct device_type *type;
		struct bus_type	*bus;		/* type of bus device is on */
		struct device_driver *driver;	/* which driver has allocated this device */
		void		*platform_data;	/* Platform specific data, device core doesn't touch it */
		void		*driver_data;	/* Driver data, set and get with*/
	}
	u64 module_pa;
	u32 module_size;
	void __iomem *module_va;
	int offsets[SYSC_MAX_REGS];
	struct ti_sysc_module_data *mdata;
	struct clk **clocks;
	{
		struct clk_core	*core;
		struct device *dev;
		const char *dev_id;
		const char *con_id;
		unsigned long min_rate;
		unsigned long max_rate;
		unsigned int exclusive_count;
		struct hlist_node clks_node;
	};
	const char **clock_roles;
	int nr_clocks;
	
	const struct sysc_capabilities  *cap = sysc_omap2
	{
		const enum ti_sysc_module_type type = TI_SYSC_OMAP2,
		const u32 sysc_mask = SYSC_OMAP2_CLOCKACTIVITY | SYSC_OMAP2_EMUFREE |
		     SYSC_OMAP2_ENAWAKEUP | SYSC_OMAP2_SOFTRESET |
		     SYSC_OMAP2_AUTOIDLE,
		const struct sysc_regbits *regbits = &sysc_regbits_omap2,
		const u32 mod_quirks;
	};

	struct sysc_config cfg 
	{
		u32 sysc_val;
		u32 syss_mask;
		u8 midlemodes;
		u8 sidlemodes; = //device tree property: ti,sysc-sidle
		u8 srst_udelay;
		u32 quirks;
	};

	const char *name;
	unsigned int reserved:1;
};
---------------------------------------------------------------------------------------------------------------------
		target-module@2a000 {			/* 0x4802a000, ap 14 2a.0 */
			compatible = "ti,sysc-omap2", "ti,sysc";
			reg = <0x2a000 0x8>,
			      <0x2a010 0x8>,
			      <0x2a090 0x8>;
			reg-names = "rev", "sysc", "syss";
			ti,sysc-mask = <(SYSC_OMAP2_CLOCKACTIVITY |
					 SYSC_OMAP2_ENAWAKEUP |
					 SYSC_OMAP2_SOFTRESET |
					 SYSC_OMAP2_AUTOIDLE)>;
			ti,sysc-sidle = <SYSC_IDLE_FORCE>,
					<SYSC_IDLE_NO>,
					<SYSC_IDLE_SMART>,
					<SYSC_IDLE_SMART_WKUP>;
			ti,syss-mask = <1>;
			/* Domains (P, C): per_pwrdm, l4ls_clkdm */
			clocks = <&l4ls_clkctrl AM3_L4LS_I2C2_CLKCTRL 0>;
			clock-names = "fck";
			#address-cells = <1>;
			#size-cells = <1>;
			ranges = <0x0 0x2a000 0x1000>;

			i2c1: i2c@0 {
				compatible = "ti,omap4-i2c";
				#address-cells = <1>;
				#size-cells = <0>;
				reg = <0x0 0x1000>;
				interrupts = <71>;
				status = "disabled";
			};
		};
	
***********************************	
reg = <0x2a000 0x8>,
	  <0x2a010 0x8>,
	  <0x2a090 0x8>;
reg-names = "rev", "sysc", "syss"

ddata->offsets[SYSC_REVISION] = 0x2a000
ddata->offsets[SYSC_SYSCONFIG] = 0x2a010
ddata->offsets[SYSC_SYSSTATUS] = 0x2a090
***********************************
ti,sysc-mask = <(SYSC_OMAP2_CLOCKACTIVITY |
		 SYSC_OMAP2_ENAWAKEUP |
		 SYSC_OMAP2_SOFTRESET |
		 SYSC_OMAP2_AUTOIDLE)>;
		 
error = of_property_read_u32(np, "ti,sysc-mask", &val);
	val değişkenine ti,sysc-mask property si okunur
	
error = sysc_init_sysc_mask(ddata); //içerisinde
ddata->cfg.sysc_val = val & ddata->cap->sysc_mask;
	ddata->cap->sysc_mask daha önce int sysc_init_match(struct sysc *ddata) içerisinde aşağıdaki gibi atanmıştır.
	ddata->cap = sysc_omap2; // in static int sysc_init_match(struct sysc *ddata)
	ddata->cap = SYSC_OMAP2_CLOCKACTIVITY | SYSC_OMAP2_EMUFREE |
				 SYSC_OMAP2_ENAWAKEUP | SYSC_OMAP2_SOFTRESET |
				 SYSC_OMAP2_AUTOIDLE,
***********************************				 
ti,sysc-sidle = <SYSC_IDLE_FORCE>,
		<SYSC_IDLE_NO>,
		<SYSC_IDLE_SMART>,
		<SYSC_IDLE_SMART_WKUP>;
		
static int sysc_init_idlemodes(struct sysc *ddata)
	error = sysc_init_idlemode(ddata, &ddata->cfg.sidlemodes, "ti,sysc-sidle");
	
	yukaridaki gibi ddata->cfg.sidlemodes

static int sysc_enable_module(struct device *dev)
	idlemodes = ddata->cfg.sidlemodes;
	sonrasında bu değere göre içeride bir takım settingler yapılır
	verilen ti,sysc-sidle değeri direk registera yazılmayabilir.
	bu propert değeri alınıp içerde iflere girdirilip birtakım
	işlemler yapılıyor
	
***********************************
ti,syss-mask = <1>;
	
static int sysc_init_syss_mask(struct sysc *ddata)
	error = of_property_read_u32(np, "ti,syss-mask", &val);
	ddata->cfg.syss_mask = val;
	
	ddata->cfg.syss_mask değeri aşağıdaki fonksiyon içerisinde bazı kontrollerde kullanılmaktadır.
	static int sysc_poll_reset_sysstatus(struct sysc *ddata) 
	
	static int sysc_probe(struct platform_device *pdev)
		static int sysc_init_module(struct sysc *ddata)	
			static int sysc_reset(struct sysc *ddata)
				static int sysc_wait_softreset(struct sysc *ddata)
					static int sysc_poll_reset_sysstatus(struct sysc *ddata) 
					
***********************************				
clocks = <&l4ls_clkctrl AM3_L4LS_I2C2_CLKCTRL 0>;
clock-names = "fck";

static const char * const clock_names[SYSC_MAX_CLOCKS] = {
	"fck", "ick", "opt0", "opt1", "opt2", "opt3", "opt4",
	"opt5", "opt6", "opt7",
};

struct clk **clocks;
{
	struct clk_core	*core;
	struct device *dev;
	const char *dev_id;
	const char *con_id;
	unsigned long min_rate;
	unsigned long max_rate;
	unsigned int exclusive_count;
	struct hlist_node clks_node;
};

print ddata->dev->of_node->name
	
static int sysc_get_clocks(struct sysc *ddata)
	ddata->clock_roles[ddata->nr_clocks] = of_property_for_each_string(np, "clock-names", prop, name) = "fck"
	static int sysc_get_one_clock(struct sysc *ddata, const char *name)
		ddata->clocks[index] = devm_clk_get(ddata->dev, name);
		struct clk *devm_clk_get(struct device *dev = ddata->dev, const char *id = name)
			struct clk *clk_get(struct device *dev = ddata->dev, const char *con_id = name)
				struct clk_hw *of_clk_get_hw(struct device_node *np = ddata->dev->of_node, int index = 0, const char *con_id = name)
					struct of_phandle_args clkspec; 
					{
						struct device_node *np;
						int args_count;
						uint32_t args[MAX_PHANDLE_ARGS];
					};
					static int of_parse_clkspec(const struct device_node *np = ddata->dev->of_node, int index=0, const char *name = name, struct of_phandle_args *out_args= clkspec)
					
in 
struct clk_hw *of_clk_get_hw(struct device_node *np, int index,
			     const char *con_id)
print
clkspec.np->name
clkspec.args_count
clkspec.uint32_t args[MAX_PHANDLE_ARGS]
hw->core->name
hw->core->of_node->name
hw->core->dev->name
hw->clk->dev->name
hw->clk->dev_id char*
hw->clk->con_id char*
hw->clk->min_rate u32
hw->clk->max_rate u32
hw->init->name
struct clk_hw 
{
	struct clk_core *core;
	{
		const char		*name;
		const struct clk_ops	*ops;
		struct clk_hw		*hw;
		struct device		*dev;
		struct device_node	*of_node;
	}
	struct clk *clk; 
	{
		struct clk_core	*core;
		struct device *dev;
		const char *dev_id;
		const char *con_id;
		unsigned long min_rate;
		unsigned long max_rate;
		unsigned int exclusive_count;
		struct hlist_node clks_node;
	};
	const struct clk_init_data *init;
	struct clk_init_data 
	{
		const char		*name;
	}
};

***********************************
ÖZET
i2c1 l4_wkup altında olmasının sebebi wake up modulu olması ve gerçekten L4_WAKEUP memory region
altında bulunuyor. Bu moduller bir eventle uyanıp birşeyler yapıp uyuyabilen moduller, bu yüzden 
bağlı olduğu arabirim de ayrı

static int sysc_enable_module(struct device *dev)
içerisinde ti,sysc-mask property si ile verilen mask özellikler eğer sürücünün kapasitesinde
varsa verilen reg ve reg-names property si ile gelen "sysc"> ddata->offsets[SYSC_SYSCONFIG] adresine 
yazılmaktadır.

***********************************
----------------------------------------------------------------------------------------------------------------------
static int sysc_probe(struct platform_device *pdev)
{
	pdev->dev->driver_data = ddata;
	ddata->dev = &pdev->dev;
	
}
----------------------------------------------------------------------------------------------------------------------
CLOCK DISTRUBITION
Clock Generation
– Through PRCM(Power, Reset, and Clock Management)

target-module@2a000 
{			/* 0x4802a000, ap 14 2a.0 */
	clocks = <&l4ls_clkctrl AM3_L4LS_I2C2_CLKCTRL 0>;
	clock-names = "fck";
	i2c1: i2c@0{}
}

target-module@b000 {			/* 0x44e0b000, ap 18 48.0 */

	clocks = <&l4_wkup_clkctrl AM3_L4_WKUP_I2C1_CLKCTRL 0>;
	clock-names = "fck";
	i2c0: i2c@0 {};
};


&l4_wkup {						/* 0x44c00000 */
	compatible = "ti,am33xx-l4-wkup", "simple-pm-bus";
	power-domains = <&prm_wkup>;
	clocks = <&l4_wkup_clkctrl AM3_L4_WKUP_L4_WKUP_CLKCTRL 0>;
	clock-names = "fck";
	reg = <0x44c00000 0x800>,
	      <0x44c00800 0x800>,
	      <0x44c01000 0x400>,
	      <0x44c01400 0x400>;
	reg-names = "ap", "la", "ia0", "ia1";
	#address-cells = <1>;
	#size-cells = <1>;
	ranges = <0x00000000 0x44c00000 0x100000>,	/* segment 0 */
		 <0x00100000 0x44d00000 0x100000>,	/* segment 1 */
		 <0x00200000 0x44e00000 0x100000>;	/* segment 2 */

	segment@200000 {					/* 0x44e00000 */
		compatible = "simple-pm-bus";
		#address-cells = <1>;
		#size-cells = <1>;
		ranges = <0x00000000 0x00200000 0x002000>,	/* ap 8 */
			 <0x00002000 0x00202000 0x001000>,	/* ap 9 */
			 <0x00003000 0x00203000 0x001000>,	/* ap 10 */
			 <0x00004000 0x00204000 0x001000>,	/* ap 11 */
			 <0x00005000 0x00205000 0x001000>,	/* ap 12 */
			 <0x00006000 0x00206000 0x001000>,	/* ap 13 */
			 <0x00007000 0x00207000 0x001000>,	/* ap 14 */
			 <0x00008000 0x00208000 0x001000>,	/* ap 15 */
			 <0x00009000 0x00209000 0x001000>,	/* ap 16 */
			 <0x0000a000 0x0020a000 0x001000>,	/* ap 17 */
			 <0x0000b000 0x0020b000 0x001000>,	/* ap 18 */
			 <0x0000c000 0x0020c000 0x001000>,	/* ap 19 */
			 <0x0000d000 0x0020d000 0x001000>,	/* ap 20 */
			 <0x0000f000 0x0020f000 0x001000>,	/* ap 21 */
			 <0x00010000 0x00210000 0x010000>,	/* ap 22 */
			 <0x00020000 0x00220000 0x010000>,	/* ap 23 */
			 <0x00030000 0x00230000 0x001000>,	/* ap 24 */
			 <0x00031000 0x00231000 0x001000>,	/* ap 25 */
			 <0x00032000 0x00232000 0x001000>,	/* ap 26 */
			 <0x00033000 0x00233000 0x001000>,	/* ap 27 */
			 <0x00034000 0x00234000 0x001000>,	/* ap 28 */
			 <0x00035000 0x00235000 0x001000>,	/* ap 29 */
			 <0x00036000 0x00236000 0x001000>,	/* ap 30 */
			 <0x00037000 0x00237000 0x001000>,	/* ap 31 */
			 <0x00038000 0x00238000 0x001000>,	/* ap 32 */
			 <0x00039000 0x00239000 0x001000>,	/* ap 33 */
			 <0x0003a000 0x0023a000 0x001000>,	/* ap 34 */
			 <0x0003e000 0x0023e000 0x001000>,	/* ap 35 */
			 <0x0003f000 0x0023f000 0x001000>,	/* ap 36 */
			 <0x0000e000 0x0020e000 0x001000>,	/* ap 37 */
			 <0x00040000 0x00240000 0x040000>,	/* ap 38 */
			 <0x00080000 0x00280000 0x001000>;	/* ap 39 */

		target-module@0 {			/* 0x44e00000, ap 8 58.0 */
			compatible = "ti,sysc-omap4", "ti,sysc";
			reg = <0 0x4>;
			reg-names = "rev";
			#address-cells = <1>;
			#size-cells = <1>;
			ranges = <0x0 0x0 0x2000>;

			prcm: prcm@0 {
				compatible = "ti,am3-prcm", "simple-bus";
				reg = <0 0x2000>;
				#address-cells = <1>;
				#size-cells = <1>;
				ranges = <0 0 0x2000>;

				prcm_clocks: clocks {
					#address-cells = <1>;
					#size-cells = <0>;
				};

				prcm_clockdomains: clockdomains {
				};
			};
		};
	}
}
		
&prcm {
	per_cm: per-cm@0 {
		compatible = "ti,omap4-cm";
		reg = <0x0 0x400>;
		#address-cells = <1>;
		#size-cells = <1>;
		ranges = <0 0x0 0x400>;

		l4ls_clkctrl: l4ls-clkctrl@38 {
			compatible = "ti,clkctrl";
			reg = <0x38 0x2c>, <0x6c 0x28>, <0xac 0xc>, <0xc0 0x1c>, <0xec 0xc>, <0x10c 0x8>, <0x130 0x4>;
			#clock-cells = <2>;
		};
	}
	
	wkup_cm: wkup-cm@400 {
	compatible = "ti,omap4-cm";
	reg = <0x400 0x100>;
	#address-cells = <1>;
	#size-cells = <1>;
	ranges = <0 0x400 0x100>;

	l4_wkup_clkctrl: l4-wkup-clkctrl@0 {
		compatible = "ti,clkctrl";
		reg = <0x0 0x10>, <0xb4 0x24>;
		#clock-cells = <2>;
	};
}