struct device 
{
...
	struct list_head	devres_head;
...
};
struct devres_node 
{
	struct list_head		entry;
	dr_release_t			release;
	const char			*name;
	size_t				size;
};
struct devres 
{
	struct devres_node		node;
	u8 __aligned(ARCH_KMALLOC_MINALIGN) data[];
};

struct platform_device *pdev = struct platform_device{platform_driver omap_i2c_driver->driver->bus->p->(struct device *)klist_devices}

void devres_add(struct device *dev , void *res)
{
	struct devres *dr = container_of(res, struct devres, data);
	unsigned long flags;

	spin_lock_irqsave(&dev->devres_lock, flags);
	add_dr(dev, &dr->node);
	static void add_dr(truct device *dev , struct devres_node *node = &dr->node)
	{
		devres_log(dev, node, "ADD");
		BUG_ON(!list_empty(&node->entry));
		list_add_tail(&node->entry, &dev->devres_head);
		static inline void list_add_tail(struct list_head *new, struct list_head *head)
	}
	spin_unlock_irqrestore(&dev->devres_lock, flags);
}

-struct device->struct list_head	devres_head; device structure ının device resource larının linked listesini tutmaktadır
 bu linked listeye yeni bir  struct devres->struct list_head		entry eklenir. 