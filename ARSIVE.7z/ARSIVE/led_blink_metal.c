
//CLOCK ENABLE
CM_PER 0x44E0_0000 0x44E0_03FF 1KB Clock Module Peripheral Registers
ACh CM_PER_GPIO1_CLKCTRL Section 8.1.12.1.29
0h CM_PER_L4LS_CLKSTCTRL Section 8.1.12.1.1

//CM_PER + CM_PER_GPIO1_CLKCTRL |= 0x02u;
*(0x44E00000 + 0xAC) |= 0x02; 	//CM_PER_GPIO1_CLKCTRL_MODULEMODE_ENABLE
while(0x02 != *(0x44E00000 + 0xAC) & 0x00000003u)

*(0x44E00000 + 0xAC) |= 0x00040000u; 	//CM_PER_GPIO1_CLKCTRL_OPTFCLKEN_GPIO_1_GDBCLK
while(0x00040000u != *(0x44E00000 + 0xAC) & 0x00040000u)

while((0x0u << 0x00000010u) != *(0x44E00000 + 0xAC) & (0x00030000u))	//CM_PER_GPIO1_CLKCTRL_IDLEST

while(0x00080000u != *(0x44E00000 + 0x0) & 0x00080000u)	//CM_PER_L4LS_CLKSTCTRL_CLKACTIVITY_GPIO_1_GDBCLK




//PINMUX SETUP
Control Module 0x44E1_0000 0x44E1_1FFF 128KB Control Module Registers
(0x44E10000 + 840 + (7*4)) = 7;




//GPIO ENABLE
//GPIO1 0x4804_C000 0x4804_CFFF 4KB GPIO1 Registers
//130h GPIO_CTRL Section 25.4.1.15

*(0x4804C000 + 0X130) &= ~(0x00000001u)




//MODULE RESET
//GPIO1 0x4804_C000 0x4804_CFFF 4KB GPIO1 Registers
//10h GPIO_SYSCONFIG Section 25.4.1.2
//114h GPIO_SYSSTATUS Section 25.4.1.14

*(0x4804C000 + 0x10) |=  (0x00000002u)
while(!(*(0x4804C000 + 0x114) & (0x00000001u)))



//DIR SET
//134h GPIO_OE Section 25.4.1.16
*(0x4804C000 + 0x134) &= ~(1 << 23);


//WRITE OUTPUT HIGH
//194h GPIO_SETDATAOUT Section 25.4.1.26
*(0x4804C000 + 0x194) = (1 << 23);

//WRITE OUTPUT LOW
//194h GPIO_SETDATAOUT Section 25.4.1.26
*(0x4804C000 + 0x194) = (1 << 23);





	//YZC EDIT START
	pr_info("configure_kgdboc entered\n");
    void __iomem *virt_addr;
	phys_addr_t phys_addr;
	volatile uint32_t readData;
	volatile uint32_t cntrx;

	//PGIO1_23 OUTPUT HIGH
	//CLOCK ENABLE
	//CM_PER_GPIO1_CLKCTRL_MODULEMODE_ENABLE
	phys_addr = 0x44E00000 + 0xAC; // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	if (virt_addr) 
	{
		readData = __raw_readl(virt_addr);
		readData |= 0x02;

		__raw_writel(readData, virt_addr);
		readData = __raw_readl(virt_addr);
		for(cntrx = 0; (cntrx < 1000000) && (0x02 != (readData & 0x00000003u)); cntrx++)
		{
			readData = __raw_readl(virt_addr);
		}
		pr_info("write read register phys_addr:%x, cntrx:%x\n", phys_addr, cntrx);
    	iounmap(virt_addr);
    }
	else
	{
        pr_info("Failed to map physical address to virtual address\n");
	}

	
	//CLOCK ENABLE
	//CM_PER_GPIO1_CLKCTRL_OPTFCLKEN_GPIO_1_GDBCLK
	//CM_PER_GPIO1_CLKCTRL_IDLEST
	phys_addr = 0x44E00000 + 0xAC; // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	if (virt_addr) 
	{
		readData = __raw_readl(virt_addr);
		readData |= 0x00040000u;

		__raw_writel(readData, virt_addr);
		readData = __raw_readl(virt_addr);
		for(cntrx = 0; (cntrx < 1000000) && (0x00040000u != (readData & 0x00040000u)); cntrx++)	//CM_PER_GPIO1_CLKCTRL_OPTFCLKEN_GPIO_1_GDBCLK
		{
			readData = __raw_readl(virt_addr);
		}
		pr_info("write read register phys_addr:%x, cntrx:%x\n", phys_addr, cntrx);
		for(cntrx = 0; (cntrx < 1000000) && ((0x0u << 0x00000010u) != (readData & 0x00030000u)); cntrx++) //CM_PER_GPIO1_CLKCTRL_IDLEST
		{
			readData = __raw_readl(virt_addr);
		}
		pr_info("write read register phys_addr:%x, cntrx:%x\n", phys_addr, cntrx);
    	iounmap(virt_addr);
    }
	else
	{
        pr_info("Failed to map physical address to virtual address\n");
	}

	//CLOCK ENABLE
	//CM_PER_L4LS_CLKSTCTRL_CLKACTIVITY_GPIO_1_GDBCLK
	phys_addr = 0x44E00000 + 0x00; // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	if (virt_addr) 
	{
		readData = __raw_readl(virt_addr);
		for(cntrx = 0; (cntrx < 1000000) && (0x00080000u != (readData & 0x00080000u)); cntrx++)	//CM_PER_GPIO1_CLKCTRL_OPTFCLKEN_GPIO_1_GDBCLK
		{
			readData = __raw_readl(virt_addr);
		}
		pr_info("write read register phys_addr:%x, cntrx:%x\n", phys_addr, cntrx);
    	iounmap(virt_addr);
    }
	else
	{
        pr_info("Failed to map physical address to virtual address\n");
	}


	//PINMUX SETUP
	//CM_PER_GPIO1_CLKCTRL_MODULEMODE_ENABLE
	phys_addr = 0x44E10000 + 840 + (7*4); // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	if (virt_addr) 
	{
		readData = 7;
		__raw_writel(readData, virt_addr);
    	iounmap(virt_addr);
    }
	else
	{
        pr_info("Failed to map physical address to virtual address\n");
	}



	//GPIO ENABLE
	phys_addr = 0x4804C000 + 0x130; // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	if (virt_addr) 
	{
		readData = __raw_readl(virt_addr);
		readData &= ~(0x00000001u);
		__raw_writel(readData, virt_addr);
    	iounmap(virt_addr);
    }
	else
	{
        pr_info("Failed to map physical address to virtual address\n");
	}


	//MODULE RESET
	phys_addr = 0x4804C000 + 0x10; // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	if (virt_addr) 
	{
		readData = __raw_readl(virt_addr);
		readData |=  (0x00000002u);
		__raw_writel(readData, virt_addr);
    	iounmap(virt_addr);
    }
	else
	{
        pr_info("Failed to map physical address to virtual address\n");
	}

	//MODULE RESET WAIT FOR
	phys_addr = 0x4804C000 + 0x114; // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	if (virt_addr) 
	{
		readData = __raw_readl(virt_addr);
		for(cntrx = 0; (cntrx < 1000000) && (0x00000001u != (readData & 0x00000001u)); cntrx++)	//CM_PER_GPIO1_CLKCTRL_OPTFCLKEN_GPIO_1_GDBCLK
		{
			readData = __raw_readl(virt_addr);
		}
    	iounmap(virt_addr);
    }
	else
	{
        pr_info("Failed to map physical address to virtual address\n");
	}

	


	//DIR SET
	phys_addr = 0x4804C000 + 0x134; // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	if (virt_addr) 
	{
		readData = __raw_readl(virt_addr);
		readData  &= ~(1 << 23);
		__raw_writel(readData, virt_addr);
    	iounmap(virt_addr);
    }
	else
	{
        pr_info("Failed to map physical address to virtual address\n");
	}




	//WRITE OUTPUT HIGH
	phys_addr = 0x4804C000 + 0x194; // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	if (virt_addr) 
	{
		readData = (1 << 23);
		__raw_writel(readData, virt_addr);
    	iounmap(virt_addr);
    }
	else
	{
        pr_info("Failed to map physical address to virtual address\n");
	}
	for(cntrx = 0; cntrx < 5000000; cntrx++);
	//YZC EDIT END





















	//WRITE OUTPUT HIGH OR LOW
	//0x4804C000 + 0x190 :clear output
	//0x4804C000 + 0x194 :set output
	volatile unsigned int ix, jx, setAdd, clearAdd, setData;
	volatile unsigned int addressx = (volatile unsigned int)port->set_termios;
	phys_addr = 0x4804C000 + 0x190; // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	clearAdd = virt_addr;
	phys_addr = 0x4804C000 + 0x194; // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	setAdd = virt_addr;
	if ((setAdd !=0) && (clearAdd != 0)) 
	{
		setData = (1 << 23);
		for(ix = 0; ix < 32; ix++)
		{
			__raw_writel(setData, setAdd);
			for(jx = 0; jx < 1000; jx++);
			__raw_writel(setData, clearAdd);
			for(jx = 0; jx < 1000; jx++);
			__raw_writel(setData, setAdd);
			for(jx = 0; jx < 1000; jx++);
			__raw_writel(setData, clearAdd);
			for(jx = 0; jx < 1000; jx++);
			__raw_writel(setData, setAdd);
			for(jx = 0; jx < 1000; jx++);
			__raw_writel(setData, clearAdd);
			for(jx = 0; jx < 1000; jx++);
			__raw_writel(setData, setAdd);
			for(jx = 0; jx < 1000; jx++);
			__raw_writel(setData, clearAdd);
			for(jx = 0; jx < 1000; jx++);
			if(((addressx >> ix) & 0x1u) == 0x1u)
			{
				__raw_writel(setData, setAdd);
			}
			else
			{
				__raw_writel(setData, clearAdd);
			}
			for(jx = 0; jx < 8000; jx++);

		}
		__raw_writel(setData, setAdd);
    	iounmap(clearAdd);
    	iounmap(setAdd);
    }
	else
	{
        pr_info("Failed to map physical address to virtual address\n");
	}
	for(cntrx = 0; cntrx < 100000000; cntrx++);
	
	
	
	
	
	
	
	//BLINK OUTPUT
	//0x4804C000 + 0x190 :clear output
	//0x4804C000 + 0x194 :set output
	volatile unsigned int ix, jx, setAdd, clearAdd, setData;
	volatile unsigned int addressx = (volatile unsigned int)port->set_termios;
	phys_addr = 0x4804C000 + 0x190; // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	clearAdd = virt_addr;
	phys_addr = 0x4804C000 + 0x194; // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	setAdd = virt_addr;
	if ((setAdd !=0) && (clearAdd != 0)) 
	{
		for(ix = 0; ix < 32; ix++)
		{
			__raw_writel(setData, setAdd);
			for(jx = 0; jx < 160000000; jx++);
			__raw_writel(setData, clearAdd);
			for(jx = 0; jx < 160000000; jx++);
		}
		__raw_writel(setData, setAdd);
    	iounmap(clearAdd);
    	iounmap(setAdd);
    }
	else
	{
        pr_info("Failed to map physical address to virtual address\n");
	}
	for(cntrx = 0; cntrx < 160000000; cntrx++);
	
	
	

	//BLINK ADDRESS OUTPUT
	//0x4804C000 + 0x190 :clear output
	//0x4804C000 + 0x194 :set output
	volatile unsigned int ix, jx, setAdd, clearAdd, setData;
	phys_addr = 0x4804C000 + 0x190; // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	clearAdd = virt_addr;
	phys_addr = 0x4804C000 + 0x194; // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	setAdd = virt_addr;
	volatile unsigned int addressx = (volatile unsigned int)port->ops->set_termios;
	if ((setAdd !=0) && (clearAdd != 0)) 
	{
		for(ix = 0; ix < 32; ix++)
		{
			__raw_writel(setData, setAdd);
			for(jx = 0; jx < 20000000; jx++);
			__raw_writel(setData, clearAdd);
			for(jx = 0; jx < 20000000; jx++);
			__raw_writel(setData, setAdd);
			for(jx = 0; jx < 20000000; jx++);
			__raw_writel(setData, clearAdd);
			for(jx = 0; jx < 20000000; jx++);
			if(((addressx >> ix) & 0x01u) == 0x01u)
			{
				__raw_writel(setData, setAdd);
			}
			else
			{
				__raw_writel(setData, clearAdd);
			}
			for(jx = 0; jx < 160000000; jx++);
		}
		__raw_writel(setData, setAdd);
    	iounmap(clearAdd);
    	iounmap(setAdd);
    }
	else
	{
        pr_info("Failed to map physical address to virtual address\n");
	}
	for(cntrx = 0; cntrx < 160000000; cntrx++);

	//YZC EDIT END
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//YZC EDIT START
	pr_info("configure_kgdboc entered\n");
    void __iomem *virt_addr;
	phys_addr_t phys_addr;
	volatile uint32_t readData;
	volatile uint32_t cntrx;

	//PGIO1_23 OUTPUT HIGH
	//CLOCK ENABLE
	//CM_PER_GPIO1_CLKCTRL_MODULEMODE_ENABLE
	phys_addr = 0x44E00000 + 0xAC; // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	if (virt_addr) 
	{
		readData = __raw_readl(virt_addr);
		readData |= 0x02;

		__raw_writel(readData, virt_addr);
		readData = __raw_readl(virt_addr);
		for(cntrx = 0; (cntrx < 1000000) && (0x02 != (readData & 0x00000003u)); cntrx++)
		{
			readData = __raw_readl(virt_addr);
		}
		pr_info("write read register phys_addr:%x, cntrx:%x\n", phys_addr, cntrx);
    	iounmap(virt_addr);
    }
	else
	{
        pr_info("Failed to map physical address to virtual address\n");
	}

	
	//CLOCK ENABLE
	//CM_PER_GPIO1_CLKCTRL_OPTFCLKEN_GPIO_1_GDBCLK
	//CM_PER_GPIO1_CLKCTRL_IDLEST
	phys_addr = 0x44E00000 + 0xAC; // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	if (virt_addr) 
	{
		readData = __raw_readl(virt_addr);
		readData |= 0x00040000u;

		__raw_writel(readData, virt_addr);
		readData = __raw_readl(virt_addr);
		for(cntrx = 0; (cntrx < 1000000) && (0x00040000u != (readData & 0x00040000u)); cntrx++)	//CM_PER_GPIO1_CLKCTRL_OPTFCLKEN_GPIO_1_GDBCLK
		{
			readData = __raw_readl(virt_addr);
		}
		pr_info("write read register phys_addr:%x, cntrx:%x\n", phys_addr, cntrx);
		for(cntrx = 0; (cntrx < 1000000) && ((0x0u << 0x00000010u) != (readData & 0x00030000u)); cntrx++) //CM_PER_GPIO1_CLKCTRL_IDLEST
		{
			readData = __raw_readl(virt_addr);
		}
		pr_info("write read register phys_addr:%x, cntrx:%x\n", phys_addr, cntrx);
    	iounmap(virt_addr);
    }
	else
	{
        pr_info("Failed to map physical address to virtual address\n");
	}

	//CLOCK ENABLE
	//CM_PER_L4LS_CLKSTCTRL_CLKACTIVITY_GPIO_1_GDBCLK
	phys_addr = 0x44E00000 + 0x00; // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	if (virt_addr) 
	{
		readData = __raw_readl(virt_addr);
		for(cntrx = 0; (cntrx < 1000000) && (0x00080000u != (readData & 0x00080000u)); cntrx++)	//CM_PER_GPIO1_CLKCTRL_OPTFCLKEN_GPIO_1_GDBCLK
		{
			readData = __raw_readl(virt_addr);
		}
		pr_info("write read register phys_addr:%x, cntrx:%x\n", phys_addr, cntrx);
    	iounmap(virt_addr);
    }
	else
	{
        pr_info("Failed to map physical address to virtual address\n");
	}


	//PINMUX SETUP
	//CM_PER_GPIO1_CLKCTRL_MODULEMODE_ENABLE
	phys_addr = 0x44E10000 + 840 + (7*4); // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	if (virt_addr) 
	{
		readData = 7;
		__raw_writel(readData, virt_addr);
    	iounmap(virt_addr);
    }
	else
	{
        pr_info("Failed to map physical address to virtual address\n");
	}



	//GPIO ENABLE
	phys_addr = 0x4804C000 + 0x130; // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	if (virt_addr) 
	{
		readData = __raw_readl(virt_addr);
		readData &= ~(0x00000001u);
		__raw_writel(readData, virt_addr);
    	iounmap(virt_addr);
    }
	else
	{
        pr_info("Failed to map physical address to virtual address\n");
	}


	//MODULE RESET
	phys_addr = 0x4804C000 + 0x10; // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	if (virt_addr) 
	{
		readData = __raw_readl(virt_addr);
		readData |=  (0x00000002u);
		__raw_writel(readData, virt_addr);
    	iounmap(virt_addr);
    }
	else
	{
        pr_info("Failed to map physical address to virtual address\n");
	}

	//MODULE RESET WAIT FOR
	phys_addr = 0x4804C000 + 0x114; // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	if (virt_addr) 
	{
		readData = __raw_readl(virt_addr);
		for(cntrx = 0; (cntrx < 1000000) && (0x00000001u != (readData & 0x00000001u)); cntrx++)	//CM_PER_GPIO1_CLKCTRL_OPTFCLKEN_GPIO_1_GDBCLK
		{
			readData = __raw_readl(virt_addr);
		}
    	iounmap(virt_addr);
    }
	else
	{
        pr_info("Failed to map physical address to virtual address\n");
	}

	


	//DIR SET
	phys_addr = 0x4804C000 + 0x134; // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	if (virt_addr) 
	{
		readData = __raw_readl(virt_addr);
		readData  &= ~(1 << 23);
		__raw_writel(readData, virt_addr);
    	iounmap(virt_addr);
    }
	else
	{
        pr_info("Failed to map physical address to virtual address\n");
	}



	//BLINK OUTPUT
	//0x4804C000 + 0x190 :clear output
	//0x4804C000 + 0x194 :set output
	volatile unsigned int ix, jx, setAdd, clearAdd, setData;
	phys_addr = 0x4804C000 + 0x190; // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	clearAdd = virt_addr;
	phys_addr = 0x4804C000 + 0x194; // Replace with your physical address
    virt_addr = ioremap(phys_addr, sizeof(unsigned long));
	setAdd = virt_addr;
	if ((setAdd !=0) && (clearAdd != 0)) 
	{
		for(ix = 0; ix < 4; ix++)
		{
			__raw_writel(setData, setAdd);
			for(jx = 0; jx < 160000000; jx++);
			__raw_writel(setData, clearAdd);
			for(jx = 0; jx < 160000000; jx++);
		}
		__raw_writel(setData, setAdd);
    	iounmap(clearAdd);
    	iounmap(setAdd);
    }
	else
	{
        pr_info("Failed to map physical address to virtual address\n");
	}
	for(cntrx = 0; cntrx < 160000000; cntrx++);
	//YZC EDIT END