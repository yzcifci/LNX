struct platform_device {
	const char	*name;
	int		id;
	bool		id_auto;
	struct device dev;
	{
		struct kobject kobj;
		struct device		*parent;

		struct device_private	*p;

		const char		*init_name; /* initial name of the device */
		const struct device_type *type;

		struct bus_type	*bus;		/* type of bus device is on */
		struct device_driver *driver;	/* which driver has allocated this
						   device */
		void		*platform_data;	/* Platform specific data, device
						   core doesn't touch it */
		void		*driver_data;	/* Driver data, set and get with
						   dev_set_drvdata/dev_get_drvdata */
	#ifdef CONFIG_PROVE_LOCKING
		struct mutex		lockdep_mutex;
	#endif
		struct mutex		mutex;	/* mutex to synchronize calls to
						 * its driver.
						 */

		struct dev_links_info	links;
		struct dev_pm_info	power;
		struct dev_pm_domain	*pm_domain;

	#ifdef CONFIG_ENERGY_MODEL
		struct em_perf_domain	*em_pd;
	#endif

	#ifdef CONFIG_GENERIC_MSI_IRQ_DOMAIN
		struct irq_domain	*msi_domain;
	#endif
	#ifdef CONFIG_PINCTRL
		struct dev_pin_info	*pins; 
		{
			struct pinctrl *p;
			struct pinctrl_state *default_state;
			struct pinctrl_state *init_state;
		#ifdef CONFIG_PM
			struct pinctrl_state *sleep_state;
			struct pinctrl_state *idle_state;
		#endif
		};
	#endif
	#ifdef CONFIG_GENERIC_MSI_IRQ
		raw_spinlock_t		msi_lock;
		struct list_head	msi_list;
	#endif
	#ifdef CONFIG_DMA_OPS
		const struct dma_map_ops *dma_ops;
	#endif
		u64		*dma_mask;	/* dma mask (if dma'able device) */
		u64		coherent_dma_mask;/* Like dma_mask, but for
							 alloc_coherent mappings as
							 not all hardware supports
							 64 bit addresses for consistent
							 allocations such descriptors. */
		u64		bus_dma_limit;	/* upstream dma constraint */
		const struct bus_dma_region *dma_range_map;

		struct device_dma_parameters *dma_parms;

		struct list_head	dma_pools;	/* dma pools (if dma'ble) */

	#ifdef CONFIG_DMA_DECLARE_COHERENT
		struct dma_coherent_mem	*dma_mem; /* internal for coherent mem
							 override */
	#endif
	#ifdef CONFIG_DMA_CMA
		struct cma *cma_area;		/* contiguous memory area for dma
						   allocations */
	#endif
	#ifdef CONFIG_SWIOTLB
		struct io_tlb_mem *dma_io_tlb_mem;
	#endif
		/* arch specific additions */
		struct dev_archdata	archdata;

		struct device_node	*of_node; /* associated device tree node */ 
		{
			const char *name;
			phandle phandle;
			const char *full_name;
			struct fwnode_handle fwnode;

			struct	property *properties;
			struct	property *deadprops;	/* removed properties */
			struct	device_node *parent;
			struct	device_node *child;
			struct	device_node *sibling;
		#if defined(CONFIG_OF_KOBJ)
			struct	kobject kobj;
		#endif
			unsigned long _flags;
			void	*data;
		#if defined(CONFIG_SPARC)
			unsigned int unique_id;
			struct of_irq_controller *irq_trans;
		#endif
		};
		struct fwnode_handle	*fwnode; /* firmware device node */

	#ifdef CONFIG_NUMA
		int		numa_node;	/* NUMA node this device is close to */
	#endif
		dev_t			devt;	/* dev_t, creates the sysfs "dev" */
		u32			id;	/* device instance */

		spinlock_t		devres_lock;
		struct list_head	devres_head;

		struct class		*class;
		const struct attribute_group **groups;	/* optional groups */

		void	(*release)(struct device *dev);
		struct iommu_group	*iommu_group;
		struct dev_iommu	*iommu;

		enum device_removable	removable;

		bool			offline_disabled:1;
		bool			offline:1;
		bool			of_node_reused:1;
		bool			state_synced:1;
		bool			can_match:1;
	#if defined(CONFIG_ARCH_HAS_SYNC_DMA_FOR_DEVICE) || \
		defined(CONFIG_ARCH_HAS_SYNC_DMA_FOR_CPU) || \
		defined(CONFIG_ARCH_HAS_SYNC_DMA_FOR_CPU_ALL)
		bool			dma_coherent:1;
	#endif
	#ifdef CONFIG_DMA_OPS_BYPASS
		bool			dma_ops_bypass : 1;
	#endif
	};
	u64		platform_dma_mask;
	struct device_dma_parameters dma_parms;
	u32		num_resources;
	struct resource	*resource;

	const struct platform_device_id	*id_entry;
	char *driver_override; /* Driver name to force a match */

	/* MFD cell pointer */
	struct mfd_cell *mfd_cell;

	/* arch specific additions */
	struct pdev_archdata	archdata;
};


struct resource {
	resource_size_t start;
	resource_size_t end;
	const char *name;
	unsigned long flags;
	unsigned long desc;
	struct resource *parent, *sibling, *child;
};

struct platform_device *pdev = struct platform_device{platform_driver omap_i2c_driver->driver->bus->p->(struct device *)klist_devices}
-void __iomem *devm_platform_ioremap_resource(struct platform_device *pdev, unsigned int index = 0)
 -void __iomem *devm_platform_get_and_ioremap_resource(struct platform_device *pdev, unsigned int index = 0, struct resource **res = NULL)
  -struct resource *platform_get_resource(struct platform_device *dev = pdev, unsigned int type = IORESOURCE_MEM, unsigned int num = 0)
  -void __iomem *devm_ioremap_resource(struct device *dev = pdev,  const struct resource *res = &pdev->resource[0])
   -static void __iomem * __devm_ioremap_resource(struct device *dev = &pdev->dev, const struct resource *res = &pdev->resource[0], enum devm_ioremap_type type = DEVM_IOREMAP)
    -static void __iomem *__devm_ioremap(struct device *dev = &pdev->dev, resource_size_t offset = &pdev->resource[0]->start, resource_size_t size = pdev->resource[0]->end - pdev->resource[0]->start + 1,  enum devm_ioremap_type type = DEVM_IOREMAP)
   