CONFIG_DYNAMIC_DEBUG_CORE=y
CONFIG_JUMP_LABEL=n
CONFIG_TRACE_BRANCH_PROFILING=n

#define pr_debug(fmt, ...)			\
	dynamic_pr_debug(fmt, ##__VA_ARGS__)
	
#define dynamic_pr_debug(fmt, ...)				\
	_dynamic_func_call(fmt,	__dynamic_pr_debug,		\
			   pr_fmt(fmt), ##__VA_ARGS__)
			   
#define _dynamic_func_call(fmt, func, ...)				\
	__dynamic_func_call(__UNIQUE_ID(ddebug), fmt, func, ##__VA_ARGS__)
	
#define __dynamic_func_call(id, fmt, func, ...) do {	\
	DEFINE_DYNAMIC_DEBUG_METADATA(id, fmt);		\
	if (DYNAMIC_DEBUG_BRANCH(id))			\
		func(&id, ##__VA_ARGS__);		\
} while (0)
	

#ifdef DEBUG
	#define DYNAMIC_DEBUG_BRANCH(descriptor) \
		likely(descriptor.flags & _DPRINTK_FLAGS_PRINT)
#else
	#define DYNAMIC_DEBUG_BRANCH(descriptor) \
		unlikely(descriptor.flags & _DPRINTK_FLAGS_PRINT)
#endif

#define _DPRINTK_FLAGS_PRINT	(1<<0) /* printk() a message using the format */

# define likely(x)	__builtin_expect(!!(x), 1)
# define unlikely(x)	__builtin_expect(!!(x), 0)
# define likely_notrace(x)	likely(x)
# define unlikely_notrace(x)	unlikely(x)

#define DEFINE_DYNAMIC_DEBUG_METADATA(name, fmt)		\
	static struct _ddebug  __aligned(8)			\
	__section("__dyndbg") name = {				\
		.modname = KBUILD_MODNAME,			\
		.function = __func__,				\
		.filename = __FILE__,				\
		.format = (fmt),				\
		.lineno = __LINE__,				\
		.flags = _DPRINTK_FLAGS_DEFAULT,		\
		_DPRINTK_KEY_INIT				\
	}

if (DYNAMIC_DEBUG_BRANCH(id))
if (likely(id.flags & _DPRINTK_FLAGS_PRINT))
if (likely(__UNIQUE_ID_ddebugX.flags & _DPRINTK_FLAGS_PRINT))
	





