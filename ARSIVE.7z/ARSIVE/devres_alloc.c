#define devres_alloc(release, size, gfp) \
	__devres_alloc_node(release, size, gfp, NUMA_NO_NODE, #release)
void *__devres_alloc_node(dr_release_t release, size_t size, gfp_t gfp, int nid,
			  const char *name)
{
	struct devres *dr;

	dr = alloc_dr(release, size, gfp | __GFP_ZERO, nid);
		static __always_inline struct devres * alloc_dr(dr_release_t release,
								size_t size, gfp_t gfp, int nid)
		{
			size_t tot_size;
			struct devres *dr;

			if (!check_dr_size(size, &tot_size))
				return NULL;

			dr = kmalloc_node_track_caller(tot_size, gfp, nid);
			if (unlikely(!dr))
				return NULL;

			memset(dr, 0, offsetof(struct devres, data));

			INIT_LIST_HEAD(&dr->node.entry);
			dr->node.release = release;
			return dr;
		}
	if (unlikely(!dr))
		return NULL;
	set_node_dbginfo(&dr->node, name, size);
	return dr->data;
}

struct devres 
{
	struct devres_node 		node;
	{
		struct list_head		entry;
		dr_release_t			release;
		const char			*name;
		size_t				size;
	};
	u8 __aligned(ARCH_KMALLOC_MINALIGN) data[];
};
-memory den size + sizeof(struct devres_node) kadar yer ayrılır dolayısıyla size alanı data[]
 sectionda tutulacaktır. data adresi return ettirilir.