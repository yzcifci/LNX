Generic used macros
-------------------------------------------------------------------------------------------------------------	
#define container_of(ptr, type, member) ({				\
	void *__mptr = (void *)(ptr);					\
	BUILD_BUG_ON_MSG(!__same_type(*(ptr), ((type *)0)->member) &&	\
			 !__same_type(*(ptr), void),			\
			 "pointer type mismatch in container_of()");	\
	((type *)(__mptr - offsetof(type, member))); })
	
member ögesine sahip bir type tipinde structure in adresini verir
ptr member in adresidir.
ör:

struct MyStruct {
    int a;
    float b;
    char c;
};
struct MyStruct instance;
float *ptr_b = &instance.b;
struct MyStruct *ptr_struct = container_of(ptr_b, struct MyStruct, b);

-------------------------------------------------------------------------------------------------------------	
struct list_head {
	struct list_head *next, *prev;
};
#define LIST_HEAD(name) \
	struct list_head name = LIST_HEAD_INIT(name)
#define LIST_HEAD_INIT(name) { &(name), &(name) }
ör:
static LIST_HEAD(pinctrl_list);
static struct list_head pinctrl_list = { &pinctrl_list, &pinctrl_list }
-------------------------------------------------------------------------------------------------------------
#define WRITE_ONCE(x, val)				\
({							\
	union { typeof(x) __val; char __c[1]; } __u =	\
		{ .__val = (val) }; 			\
	__write_once_size(&(x), __u.__c, sizeof(x));	\
	__u.__val;					\
})
static __always_inline void __write_once_size(volatile void *p, void *res, int size)
{
	switch (size) {
	case 1: *(volatile  __u8_alias_t *) p = *(__u8_alias_t  *) res; break;
	case 2: *(volatile __u16_alias_t *) p = *(__u16_alias_t *) res; break;
	case 4: *(volatile __u32_alias_t *) p = *(__u32_alias_t *) res; break;
	case 8: *(volatile __u64_alias_t *) p = *(__u64_alias_t *) res; break;
	default:
		barrier();
		__builtin_memcpy((void *)p, (const void *)res, size);
		barrier();
	}
}
ex:
WRITE_ONCE(uint8_t data , 12)
union 
{ 
	uint8_t* __val; 
	char __c[1]; 
} __u =	
{ 
	.__val = 12 
}; 			\
	__write_once_size(&data, __u.__c, 1);
	*(&data) = *(__u8_alias_t  *) __u.__c;
	__u.__val;					\
})	
-------------------------------------------------------------------------------------------------------------	
struct pinctrl {
	struct list_head node;
	struct device *dev;
	struct list_head states;
	struct pinctrl_state *state;
	struct list_head dt_maps;
	struct kref users;
};
#define list_for_each_entry(pos, head, member)				\
	for (pos = list_first_entry(head, typeof(*pos), member);	\
	     !list_entry_is_head(pos, head, member);			\
	     pos = list_next_entry(pos, member))
		 
#define list_first_entry(ptr, type, member) \
	list_entry((ptr)->next, type, member)
	
#define list_entry(ptr, type, member) \
	container_of(ptr, type, member)

#define list_entry_is_head(pos, head, member)				\
	(&pos->member == (head))
	
#define list_next_entry(pos, member) \
	list_entry((pos)->member.next, typeof(*(pos)), member)
	
struct pinctrl *p;	
list_for_each_entry(p, &pinctrl_list, node)	
#define list_for_each_entry(p, &pinctrl_list, node)				\
	for (p = list_first_entry(&pinctrl_list, typeof(*p), node);	\
	     !list_entry_is_head(p, &pinctrl_list, node);			\
	     p = list_next_entry(p, node))
		 
#define list_first_entry(&pinctrl_list, typeof(*p), node) \
	list_entry((&pinctrl_list)->next, typeof(*p), node)
	
#define list_entry((&pinctrl_list)->next, typeof(*p), node) \
	container_of((&pinctrl_list)->next, typeof(*p), node)
	
#define list_entry_is_head(p, &pinctrl_list, node)				\
	(&p->node == (&pinctrl_list))
	
#define list_next_entry(p, node) \
	list_entry(p->node.next, typeof(*p), node)
	
-------------------------------------------------------------------------------------------------------------	
