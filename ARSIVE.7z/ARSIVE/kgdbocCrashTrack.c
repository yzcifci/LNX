kgdboc_probe(struct platform_device *pdev)//kgdboc.c
	if(pdev->name)
	{
		pr_info("kgdboc_probe:pdev->name:%s\n", pdev->name);
	}
	configure_kgdboc()//kgdboc.c
		p = struct tty_driver *tty_find_polling_driver(char *name = cptr, int *line = &tty_line)//tty_io.c
									list_for_each_entry(p, &tty_drivers, tty_drivers)
										if(p)
										{
											if(p->ops)
											{
												if(p->ops->poll_init)
												{
													pr_info("p->ops->poll_init exists\n");
													int resultx = 0;
													resultx = p->ops->poll_init(p, tty_line, stp); //=uart_poll_init //serial_core.c
																	ret = uart_set_options(port, NULL, baud, parity, bits, flow); //serial_core.c
																				pr_info("port->ops->set_termios address virtual:%x\n", port->ops->set_termios); //port->ops->set_termios = serial8250_set_termios
																				if(port)
																				{
																					if(port->name)
																					{
																						pr_info("port->name:%s\n", port->name);
																					}
																					else
																					{
																						pr_info("port->name:NULL\n");
																					}	
																				}
																				else
																				{
																					pr_info("port is NULL\n");
																				}
																				pr_info("baud:%d\n", baud);
																				if(co)
																				{
																					pr_info("co->name:%s\n", co->name);
																				}
																				else
																				{
																					pr_info("console not exists\n");
																				}
																				if(baud == 9600)
																				{
																					return 0;
																				}
													pr_info("p->ops->poll_init address virtual:%x, physical:%x\n", p->ops->poll_init, virt_to_phys(p->ops->poll_init));
													pr_info("resultx:%d\n", resultx);
													mutex_unlock(&tty_mutex);
													return NULL;
												}
												else
												{
													pr_info("p->ops->poll_init is null\n");
													mutex_unlock(&tty_mutex);
													return NULL;
												}
											}
											else
											{
												pr_info("p->opsis null\n");
												mutex_unlock(&tty_mutex);
												return NULL;
											}

										}
										else
										{
											pr_info("p is null\n");
											mutex_unlock(&tty_mutex);
											return NULL;
										}
		if(cptr)
		{
			pr_info("configure_kgdboc cptr:%s\n", cptr);
		}
		return -ENODEV;
	pr_info("ret:%d\n", ret);	
	