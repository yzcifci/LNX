#define DECLARE_EVENT_CLASS(name, proto, args, tstruct, assign, print)

trace/events/....h