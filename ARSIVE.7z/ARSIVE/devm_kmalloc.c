void *devm_kmalloc(struct device *dev, size_t size, gfp_t gfp)
{
	struct devres *dr;

	if (unlikely(!size))
		return ZERO_SIZE_PTR;
	//size değeri genelde sıfır gelmez eğer sıfır gelmişse return ZERO_SIZE_PTR;
	
	/* use raw alloc_dr for kmalloc caller tracing */
	dr = alloc_dr(devm_kmalloc_release, size, gfp, dev_to_node(dev));
	static __always_inline struct devres * alloc_dr(dr_release_t release,
						size_t size, gfp_t gfp, int nid)
	{
		size_t tot_size;
		struct devres *dr;

		if (!check_dr_size(size, &tot_size))
		static bool check_dr_size(size_t size, size_t *tot_size)
		{
			/* We must catch any near-SIZE_MAX cases that could overflow. */
			if (unlikely(check_add_overflow(sizeof(struct devres),
							size, tot_size)))
			#define check_add_overflow(a, b, d)	\
			__must_check_overflow(__builtin_add_overflow(a, b, d))
				return false;

			/* Actually allocate the full kmalloc bucket size. */
			*tot_size = kmalloc_size_roundup(*tot_size);

			return true;
		}
			return NULL;
		//check size and assign real size(sizeof(struct devres) + size) to tot_size
		
		dr = kmalloc_node_track_caller(tot_size, gfp, nid);
		#define kmalloc_node_track_caller(size, flags, node) \
		__kmalloc_node_track_caller(size, flags, node, \
						_RET_IP_)
		void *__kmalloc_node_track_caller(size_t size, gfp_t flags,
				  int node, unsigned long caller)
		{
			return __do_kmalloc_node(size, flags, node, caller);
		}
						
		if (unlikely(!dr))
			return NULL;

		/* No need to clear memory twice */
		if (!(gfp & __GFP_ZERO))
			memset(dr, 0, offsetof(struct devres, data));

		INIT_LIST_HEAD(&dr->node.entry);
		dr->node.release = release;
		return dr;
	}
	if (unlikely(!dr))
		return NULL;

	/*
	 * This is named devm_kzalloc_release for historical reasons
	 * The initial implementation did not support kmalloc, only kzalloc
	 */
	set_node_dbginfo(&dr->node, "devm_kzalloc_release", size);
	devres_add(dev, dr->data);
	return dr->data;
}