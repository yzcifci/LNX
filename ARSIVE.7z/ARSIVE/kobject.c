void kobject_init(struct kobject *kobj, struct kobj_type *ktype)
{
	kobj->kref->refcount = 1;
	kobj->entry->next = kobj->entry;
	kobj->entry->prev = kobj->entry;
	kobj->state_in_sysfs = 0;
	kobj->state_add_uevent_sent = 0;
	kobj->state_remove_uevent_sent = 0;
	kobj->state_initialized = 1;
	kobj->ktype = ktype;
	return;
}
-------------------------------------------------------------------------------------------------------------
static int kobject_add_internal(struct kobject *kobj)
{
	temel görevi 
	kobj_kset_join(struct kobject *kobj)
}

struct kset {
	struct list_head list;
	spinlock_t list_lock;
	struct kobject kobj;
	const struct kset_uevent_ops *uevent_ops;
} __randomize_layout;

struct kobject {
	const char		*name;
	struct list_head	entry;
	struct kobject		*parent;
	struct kset		*kset;
	struct kobj_type	*ktype;
	struct kernfs_node	*sd; /* sysfs directory entry */
	struct kref		kref;
#ifdef CONFIG_DEBUG_KOBJECT_RELEASE
	struct delayed_work	release;
#endif
	unsigned int state_initialized:1;
	unsigned int state_in_sysfs:1;
	unsigned int state_add_uevent_sent:1;
	unsigned int state_remove_uevent_sent:1;
	unsigned int uevent_suppress:1;
};



-------------------------------------------------------------------------------------------------------------
static void kobj_kset_join(struct kobject *kobj)
{
	kobj->kset->list listesine kobj->entry sini ekler
	aşağıdaki gibi her kobject bir kset listesine aittir. kset içerisindeki
	kobject ise bu kobject lerin parnetı olarak atanmaktadır.
	struct kobject 
	{
		const char			*name;
		struct list_head 	entry;
		struct kobject 		*parent;
		struct kset			*kset;
		...
	};
}

-------------------------------------------------------------------------------------------------------------
static __printf(3, 0) int kobject_add_varg(struct kobject *kobj,
					   struct kobject *parent,
					   const char *fmt, va_list vargs)
{
	kobj->name, const char *fmt, va_list vargs ile gelen formatla set edilir
	kobj->parent = parent; atanır
	kobject_add_internal(kobj); ile kobj_kset_join(struct kobject *kobj)/ çağrılarak
	kobj->kset->list listesine kobj->entry sini ekler
}
-------------------------------------------------------------------------------------------------------------
int kobject_init_and_add(struct kobject *kobj, struct kobj_type *ktype,
			 struct kobject *parent, const char *fmt, ...)
{
	kobj->kref->refcount = 1;
	kobj->entry->next = kobj->entry;
	kobj->entry->prev = kobj->entry;
	kobj->state_in_sysfs = 0;
	kobj->state_add_uevent_sent = 0;
	kobj->state_remove_uevent_sent = 0;
	kobj->state_initialized = 1;
	kobj->ktype = ktype;

	kobj->name, const char *fmt, va_list vargs ile gelen formatla set edilir
	kobj->parent = parent; atanır
	kobject_add_internal(kobj); ile kobj_kset_join(struct kobject *kobj) çağrılarak
	kobj->kset->list listesine kobj->entry sini ekler

	return retval;
}