struct platform_driver omap_i2c_driver =
{
	int (*probe)(struct platform_device *)									= omap_i2c_probe;
	int (*remove)(struct platform_device *)									= omap_i2c_remove;
	void (*shutdown)(struct platform_device *);		
	int (*suspend)(struct platform_device *, pm_message_t state);		
	int (*resume)(struct platform_device *);		
	struct device_driver driver;		
	{		
		const char		*name;												= "omap_i2c"
		struct bus_type		*bus;		
		{		
			const char		*name;											= "platform"
			const char		*dev_name;		
			struct device		*dev_root;		
			const struct attribute_group **bus_groups;		
			const struct attribute_group **dev_groups;						= platform_dev_groups
			const struct attribute_group **drv_groups;

			int (*match)(struct device *dev, struct device_driver *drv);	= platform_match	
			int (*uevent)(struct device *dev, struct kobj_uevent_env *env);	= platform_uevent
			int (*probe)(struct device *dev);								= platform_probe
			void (*sync_state)(struct device *dev);
			void (*remove)(struct device *dev);								= platform_remove
			void (*shutdown)(struct device *dev);							= platform_shutdown

			int (*online)(struct device *dev);
			int (*offline)(struct device *dev);

			int (*suspend)(struct device *dev, pm_message_t state);
			int (*resume)(struct device *dev);

			int (*num_vf)(struct device *dev);

			int (*dma_configure)(struct device *dev);						= platform_dma_configure

			const struct dev_pm_ops *pm;									= &platform_dev_pm_ops

			const struct iommu_ops *iommu_ops;

			struct subsys_private *p
			{
				struct kset subsys;
				struct kset *devices_kset;
				struct list_head interfaces;
				struct mutex mutex;

				struct kset *drivers_kset;
				{
					struct list_head list;
					spinlock_t list_lock;
					struct kobject kobj;
					{
						const char		*name;
						struct list_head	entry;
						struct kobject		*parent;
						struct kset		*kset;
						struct kobj_type	*ktype;
						struct kernfs_node	*sd; /* sysfs directory entry */
						struct kref		kref;
					#ifdef CONFIG_DEBUG_KOBJECT_RELEASE
						struct delayed_work	release;
					#endif
						unsigned int state_initialized:1;
						unsigned int state_in_sysfs:1;
						unsigned int state_add_uevent_sent:1;
						unsigned int state_remove_uevent_sent:1;
						unsigned int uevent_suppress:1;
					};
					const struct kset_uevent_ops *uevent_ops;
				} __randomize_layout;
				struct klist klist_devices; //(struct device*)
				struct klist klist_drivers;
				struct blocking_notifier_head bus_notifier;
				unsigned int drivers_autoprobe:1;
				struct bus_type *bus;

				struct kset glue_dirs;
				struct class *class;
			};
			struct lock_class_key lock_key;

			bool need_parent_lock;
		};

		struct module		*owner;											=null
		const char		*mod_name;	/* used for built-in modules */

		bool suppress_bind_attrs;	/* disables bind/unbind via sysfs */
		enum probe_type probe_type;

		const struct of_device_id	*of_match_table;						= of_match_ptr(omap_i2c_of_match)
		const struct acpi_device_id	*acpi_match_table;		
		
		int (*probe) (struct device *dev);									
		void (*sync_state)(struct device *dev);		
		int (*remove) (struct device *dev);		
		void (*shutdown) (struct device *dev);		
		int (*suspend) (struct device *dev, pm_message_t state);		
		int (*resume) (struct device *dev);		
		const struct attribute_group **groups;		
		const struct attribute_group **dev_groups;		
		
		const struct dev_pm_ops *pm;										=&omap_i2c_pm_ops
		void (*coredump) (struct device *dev);

		struct driver_private *p;
	};
	const struct platform_device_id *id_table;
	bool prevent_deferred_probe;
};

struct platform_device {
	const char	*name;
	int		id;
	bool		id_auto;
	struct device dev;
	{
		struct kobject kobj;
		struct device		*parent;

		struct device_private	*p;

		const char		*init_name; /* initial name of the device */
		const struct device_type *type;

		struct bus_type	*bus;		/* type of bus device is on */
		struct device_driver *driver;	/* which driver has allocated this
						   device */
		void		*platform_data;	/* Platform specific data, device
						   core doesn't touch it */
		void		*driver_data;	/* Driver data, set and get with
						   dev_set_drvdata/dev_get_drvdata */
	#ifdef CONFIG_PROVE_LOCKING
		struct mutex		lockdep_mutex;
	#endif
		struct mutex		mutex;	/* mutex to synchronize calls to
						 * its driver.
						 */

		struct dev_links_info	links;
		struct dev_pm_info	power;
		struct dev_pm_domain	*pm_domain;

	#ifdef CONFIG_ENERGY_MODEL
		struct em_perf_domain	*em_pd;
	#endif

	#ifdef CONFIG_GENERIC_MSI_IRQ_DOMAIN
		struct irq_domain	*msi_domain;
	#endif
	#ifdef CONFIG_PINCTRL
		struct dev_pin_info	*pins; 
		{
			struct pinctrl *p;
			struct pinctrl_state *default_state;
			struct pinctrl_state *init_state;
		#ifdef CONFIG_PM
			struct pinctrl_state *sleep_state;
			struct pinctrl_state *idle_state;
		#endif
		};
	#endif
	#ifdef CONFIG_GENERIC_MSI_IRQ
		raw_spinlock_t		msi_lock;
		struct list_head	msi_list;
	#endif
	#ifdef CONFIG_DMA_OPS
		const struct dma_map_ops *dma_ops;
	#endif
		u64		*dma_mask;	/* dma mask (if dma'able device) */
		u64		coherent_dma_mask;/* Like dma_mask, but for
							 alloc_coherent mappings as
							 not all hardware supports
							 64 bit addresses for consistent
							 allocations such descriptors. */
		u64		bus_dma_limit;	/* upstream dma constraint */
		const struct bus_dma_region *dma_range_map;

		struct device_dma_parameters *dma_parms;

		struct list_head	dma_pools;	/* dma pools (if dma'ble) */

	#ifdef CONFIG_DMA_DECLARE_COHERENT
		struct dma_coherent_mem	*dma_mem; /* internal for coherent mem
							 override */
	#endif
	#ifdef CONFIG_DMA_CMA
		struct cma *cma_area;		/* contiguous memory area for dma
						   allocations */
	#endif
	#ifdef CONFIG_SWIOTLB
		struct io_tlb_mem *dma_io_tlb_mem;
	#endif
		/* arch specific additions */
		struct dev_archdata	archdata;

		struct device_node	*of_node; /* associated device tree node */ 
		{
			const char *name;
			phandle phandle;
			const char *full_name;
			struct fwnode_handle fwnode;

			struct	property *properties;
			struct	property *deadprops;	/* removed properties */
			struct	device_node *parent;
			struct	device_node *child;
			struct	device_node *sibling;
		#if defined(CONFIG_OF_KOBJ)
			struct	kobject kobj;
		#endif
			unsigned long _flags;
			void	*data;
		#if defined(CONFIG_SPARC)
			unsigned int unique_id;
			struct of_irq_controller *irq_trans;
		#endif
		};
		struct fwnode_handle	*fwnode; /* firmware device node */

	#ifdef CONFIG_NUMA
		int		numa_node;	/* NUMA node this device is close to */
	#endif
		dev_t			devt;	/* dev_t, creates the sysfs "dev" */
		u32			id;	/* device instance */

		spinlock_t		devres_lock;
		struct list_head	devres_head;

		struct class		*class;
		const struct attribute_group **groups;	/* optional groups */

		void	(*release)(struct device *dev);
		struct iommu_group	*iommu_group;
		struct dev_iommu	*iommu;

		enum device_removable	removable;

		bool			offline_disabled:1;
		bool			offline:1;
		bool			of_node_reused:1;
		bool			state_synced:1;
		bool			can_match:1;
	#if defined(CONFIG_ARCH_HAS_SYNC_DMA_FOR_DEVICE) || \
		defined(CONFIG_ARCH_HAS_SYNC_DMA_FOR_CPU) || \
		defined(CONFIG_ARCH_HAS_SYNC_DMA_FOR_CPU_ALL)
		bool			dma_coherent:1;
	#endif
	#ifdef CONFIG_DMA_OPS_BYPASS
		bool			dma_ops_bypass : 1;
	#endif
	};
	u64		platform_dma_mask;
	struct device_dma_parameters dma_parms;
	u32		num_resources;
	struct resource	*resource;

	const struct platform_device_id	*id_entry;
	char *driver_override; /* Driver name to force a match */

	/* MFD cell pointer */
	struct mfd_cell *mfd_cell;

	/* arch specific additions */
	struct pdev_archdata	archdata;
};

struct property
{
	char	*name;
	int	length;
	void	*value;
	struct property *next;
#if defined(CONFIG_OF_DYNAMIC) || defined(CONFIG_SPARC)
	unsigned long _flags;
#endif
#if defined(CONFIG_OF_PROMTREE)
	unsigned int unique_id;
#endif
#if defined(CONFIG_OF_KOBJ)
	struct bin_attribute attr;
#endif
};

struct of_device_id {
	char	name[32];
	char	type[32];
	char	compatible[128];
	const void *data;
};

static const struct of_device_id omap_i2c_of_match[] = {
	{
		.compatible = "ti,omap4-i2c",
		.data = &omap4_pdata,
	},
	{
		.compatible = "ti,omap3-i2c",
		.data = &omap3_pdata,
	},
	{
		.compatible = "ti,omap2430-i2c",
		.data = &omap2430_pdata,
	},
	{
		.compatible = "ti,omap2420-i2c",
		.data = &omap2420_pdata,
	},
	{ },
};

-static int platform_match(struct device *dev, struct device_driver *drv)
 -static inline int of_driver_match_device(struct device *dev, const struct device_driver *drv)
  -const struct of_device_id *of_match_device(const struct of_device_id *drv->of_match_table, const struct device *dev)
   -const struct of_device_id *of_match_device(const struct of_device_id *drv->of_match_table, const struct device *dev)
	-const struct of_device_id *of_match_node(const struct of_device_id *drv->of_match_table, const struct device_node *dev->of_node)
	 -const struct of_device_id *of_match_node(const struct of_device_id *drv->of_match_table, const struct device_node *dev->of_node)
	  -static const struct of_device_id *__of_match_node(const struct of_device_id *matches = drv->of_match_table, const struct device_node *node = dev->of_node)
	   -static int __of_device_is_compatible(const struct device_node *device = dev->of_node, const char *compat = drv->of_match_table[n]->compatible, const char *type = drv->of_match_table[n]->type, const char *name = drv->of_match_table[n]->compatible->name)
	    -static struct property *__of_find_property(const struct device_node *np = dev->of_node, const char *name = "compatible", int *lenp = NULL)
		-const char *of_prop_next_string(struct property *prop, const char *cur)
	
...	
-static void __init do_initcalls(void)
 -static int __init omap_i2c_init_driver(void)
  -int __platform_driver_register(struct platform_driver *drv = &omap_i2c_driver, struct module *owner NULL)
   -int driver_register(struct device_driver *drv = &omap_i2c_driver->driver)
	-int bus_add_driver(struct device_driver *drv = &omap_i2c_driver->driver)
	 -int driver_attach(struct device_driver *drv = &omap_i2c_driver->driver)
	  -int bus_for_each_dev(struct bus_type *bus = &omap_i2c_driver->driver->bus, struct device *start = NULL, void *data = &omap_i2c_driver->driver, int (*fn)(struct device *, void *) = __driver_attach)
	   -static int __driver_attach(struct device *dev = platform_driver omap_i2c_driver->driver->bus->p->(struct device *)klist_devices, void *data = &omap_i2c_driver->driver)
	    -static inline int driver_match_device(struct device_driver *drv = &omap_i2c_driver->driver, struct device *dev = platform_driver omap_i2c_driver->driver->bus->p->(struct device *)klist_devices)
		 -static int platform_match(struct device *dev, struct device_driver *drv)
		*-static int driver_probe_device(void *data = &omap_i2c_driver->driver, struct device *dev = platform_driver omap_i2c_driver->driver->bus->p->klist_devices(struct device *))
	     *-static int __driver_probe_device(struct device_driver *drv = &omap_i2c_driver->driver, struct device *dev = platform_driver omap_i2c_driver->driver->bus->p->klist_devices(struct device *))
		  *-static int really_probe(struct device *dev = platform_driver omap_i2c_driver->driver->bus->p->(struct device *)klist_devices, struct device_driver *drv = &omap_i2c_driver->driver)
		   *-static int call_driver_probe(struct device *dev = platform_driver omap_i2c_driver->driver->bus->p->(struct device *)klist_devices, struct device_driver *drv = &omap_i2c_driver->driver)				
		    *-static int platform_probe(struct device *_dev = platform_driver omap_i2c_driver->driver->bus->p->(struct device *)klist_devices)
			{
				struct platform_driver *drv = to_platform_driver(_dev->driver); = struct platform_driver = struct platform_driver omap_i2c_driver
				struct platform_device *dev = to_platform_device(_dev); = struct platform_device 
				drv->probe(dev);
				omap_i2c_driver.probe =  static int omap_i2c_probe(struct platform_device *pdev = struct platform_device{platform_driver omap_i2c_driver->driver->bus->p->(struct device *)klist_devices})				
			} 

static int fw_devlink_create_devlink(struct device *con,
				     struct fwnode_handle *sup_handle, u32 flags)
-struct device_link *device_link_add(struct device *consumer,
				    struct device *supplier, u32 flags)
-int device_register(struct device *dev)			
 *int device_add(struct device *dev)
  *static void fw_devlink_link_device(struct device *dev)	
   *static void __fw_devlink_link_to_suppliers(struct device *dev, struct fwnode_handle *fwnode)			
	*static int fw_devlink_create_devlink(struct device *con,  struct fwnode_handle *sup_handle, u32 flags)
	 *struct device_link *device_link_add(struct device *consumer, struct device *supplier, u32 flags)   
	  *int device_register(struct device *dev)
	   *int device_add(struct device *dev)
		*void bus_probe_device(struct device *dev)
		 *void device_initial_probe(struct device *dev)
		  *static int __device_attach(struct device *dev, bool allow_async)
		   *static int __device_attach_driver(struct device_driver *drv, void *_data)
			*-static int driver_probe_device(void *data = &omap_i2c_driver->driver, struct device *dev = platform_driver omap_i2c_driver->driver->bus->p->klist_devices(struct device *))
			 *-static int __driver_probe_device(struct device_driver *drv = &omap_i2c_driver->driver, struct device *dev = platform_driver omap_i2c_driver->driver->bus->p->klist_devices(struct device *))
			  *-static int really_probe(struct device *dev = platform_driver omap_i2c_driver->driver->bus->p->(struct device *)klist_devices, struct device_driver *drv = &omap_i2c_driver->driver)
			   *-static int call_driver_probe(struct device *dev = platform_driver omap_i2c_driver->driver->bus->p->(struct device *)klist_devices, struct device_driver *drv = &omap_i2c_driver->driver)				
				*-static int platform_probe(struct device *_dev = platform_driver omap_i2c_driver->driver->bus->p->(struct device *)klist_devices)
				{
					struct platform_driver *drv = to_platform_driver(_dev->driver); = struct platform_driver = struct platform_driver omap_i2c_driver
					struct platform_device *dev = to_platform_device(_dev); = struct platform_device 
					drv->probe(dev);
					omap_i2c_driver.probe =  static int omap_i2c_probe(struct platform_device *pdev = struct platform_device{platform_driver omap_i2c_driver->driver->bus->p->(struct device *)klist_devices})				
				} 
#define to_platform_device(x) container_of((x), struct platform_device, dev)			
#define to_platform_device(_dev) container_of((_dev), struct platform_device, dev)	


#define to_platform_driver(drv)	(container_of((drv), struct platform_driver, driver))		
#define to_platform_driver(_dev->driver)	(container_of((_dev->driver), struct platform_driver, driver))		
static int platform_probe(struct device *_dev)
{
	struct platform_driver *drv = to_platform_driver(_dev->driver) = ;
	struct platform_device *dev = to_platform_device(_dev);
	if (drv->probe) {
		ret = drv->probe(dev);		
}
			
-int bus_for_each_dev(struct bus_type *bus = &omap_i2c_driver->driver->bus, struct device *start = NULL, void *data = &omap_i2c_driver->driver, int (*fn)(struct device *, void *) = __driver_attach)
 fonksiyonu altında struct platform_device -> struct device dev tipinde linked listten ; elemanları sırayla
 çekecek ve struct device dev ve struct device_driver *drv olarak __driver_attach fonksiyonuna gönderecektir.
 struct platform_driver omap_i2c_driver->driver->bus->p->(struct device *)klist_devices
 
-static int really_probe(struct device *dev = platform_driver omap_i2c_driver->driver->bus->p->(struct device *)klist_devices, struct device_driver *drv = &omap_i2c_driver->driver) içerisinde:
	(struct device_driver *)dev->driver = drv; eşlenir
 -int pinctrl_bind_pins(struct device *dev = struct platform_driver omap_i2c_driver->driver->bus->p->(struct device *)klist_devices)
  -struct pinctrl *devm_pinctrl_get(struct device *dev)
   -struct pinctrl *p = pinctrl_get(dev);
   -devres_add(dev, ptr);
  
  

-void devres_add(struct device *dev = struct platform_driver omap_i2c_driver->driver->bus->p->(struct device *)klist_devices, void *res = struct devres->data[4]:&pinctrl_list[n])
 -static void add_dr(struct device *dev = struct platform_driver omap_i2c_driver->driver->bus->p->(struct device *)klist_devices, struct devres_node *node = &container_of(res = struct devres->data[4]:&pinctrl_list[n], struct devres, data)->node)
  -static inline void list_add_tail(struct list_head *new = &node->entry, struct list_head *head = &dev->devres_head)
 
 

struct devres 
{
	struct devres_node		node; 
	{
		struct list_head		entry;
		dr_release_t			release;
		const char			*name;
		size_t				size;
	}; 
	u8 __aligned(ARCH_KMALLOC_MINALIGN) data[];
}; 




-static int platform_probe(struct device *_dev = platform_driver omap_i2c_driver->driver->bus->p->(struct device *)klist_devices)
