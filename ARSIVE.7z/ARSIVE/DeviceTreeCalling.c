head-common.s
b	start_kernel
-asmlinkage __visible void __init __no_sanitize_address start_kernel(void)
	-void __init __weak arch_call_rest_init(void)
		-noinline void __ref rest_init(void)
			-kernel_thread(kernel_init, NULL, CLONE_FS);
				-static int __ref kernel_init(void *unused)
					-static noinline void __init kernel_init_freeable(void)
						-static void __init do_basic_setup(void)
							-static void __init do_initcalls(void)
								
							-void __init driver_init(void)

head-common.s
b	start_kernel
	asmlinkage __visible void __init __no_sanitize_address start_kernel(void)
	{
		void __init setup_arch(char **cmdline_p)
		{
			unflatten_device_tree();
			void __init unflatten_device_tree(void)
			{
				__unflatten_device_tree(initial_boot_params, NULL, &of_root,
							early_init_dt_alloc_memory_arch, false);
				void *__unflatten_device_tree(const void *blob,
						  struct device_node *dad,
						  struct device_node **mynodes,
						  void *(*dt_alloc)(u64 size, u64 align),
						  bool detached)
				{
					ret = unflatten_dt_nodes(blob, mem, dad, mynodes);
							static int unflatten_dt_nodes(const void *blob,
						  void *mem,
						  struct device_node *dad,
						  struct device_node **nodepp)
						 {
							 ret = populate_node(blob, offset, &mem, nps[depth],
										&nps[depth+1], dryrun);
								   static int populate_node(const void *blob,
									  int offset,
									  void **mem,
									  struct device_node *dad,
									  struct device_node **pnp,
									  bool dryrun)
									{
									}
						 }
				}
			}
		}
	}