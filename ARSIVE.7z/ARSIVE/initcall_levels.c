CONFIG_HAVE_ARCH_PREL32_RELOCATIONS=n

typedef int (*initcall_t)(void);
typedef initcall_t initcall_entry_t;
#define __initdata	__section(".init.data")

static initcall_entry_t *initcall_levels[] __initdata = {
	__initcall0_start,
	__initcall1_start,
	__initcall2_start,
	__initcall3_start,
	__initcall4_start,
	__initcall5_start,
	__initcall6_start,
	__initcall7_start,
	__initcall_end,
};

-static void __init do_initcalls(void) fonksiyonu içerisinde çağrılan command_line parametresi 
 kernel command_line parametresidir. yani kernel start edilirken verilen command_line
	command_line:root=PARTUUID=b9b3dcac-02 rootwait console=ttyS0,115200 loglevel=8

-aşağıdaki şekilde functionx fonksiyonu levelx[0...7] initcall levelında tanımlanabilir
	static int __init functionx(void)
	{
		...
	}
	__define_initcall(fn, level)(functionx);

