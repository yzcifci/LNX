
static DECLARE_WORK(deferred_probe_work, deferred_probe_work_func);
#define DECLARE_WORK(n, f)						\
	struct work_struct n = __WORK_INITIALIZER(n, f)
	
#define __WORK_INITIALIZER(n, f) {					\
	.data = WORK_DATA_STATIC_INIT(),				\
	.entry	= { &(n).entry, &(n).entry },				\
	.func = (f),							\
	__WORK_INIT_LOCKDEP_MAP(#n, &(n))				\
	}
	
#define WORK_DATA_STATIC_INIT()	\
	ATOMIC_LONG_INIT((unsigned long)(WORK_STRUCT_NO_POOL | WORK_STRUCT_STATIC))
	
#define ATOMIC_LONG_INIT(i)		ATOMIC64_INIT(i)
#define ATOMIC64_INIT				ATOMIC_INIT
#define ATOMIC_INIT(i) { (i) }

static void deferred_probe_work_func(struct work_struct *work)
{
	
}
static struct work_struct deferred_probe_work =
{
	.data = 0x12;
	.entry = { &deferred_probe_work.entry, &deferred_probe_work.entry },
	.func = deferred_probe_work_func,
}

static void driver_deferred_probe_trigger(void)
{
	queue_work(system_unbound_wq, &deferred_probe_work);
	static inline bool queue_work(struct workqueue_struct *wq,
			      struct work_struct *work)
	{
		return queue_work_on(WORK_CPU_UNBOUND, wq, work);
		bool queue_work_on(int cpu, struct workqueue_struct *wq,
		   struct work_struct *work)
		{
			bool ret = false;
			unsigned long flags;

			local_irq_save(flags);

			if (!test_and_set_bit(WORK_STRUCT_PENDING_BIT, work_data_bits(work))) {
				__queue_work(cpu, wq, work);
				ret = true;
			}

			local_irq_restore(flags);
			return ret;
		}
	}
}