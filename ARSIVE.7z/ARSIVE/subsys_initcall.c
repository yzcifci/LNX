subsys_initcall(omap_i2c_init_driver);

#define subsys_initcall(fn)		__define_initcall(fn, 4)

#define __define_initcall(fn, id) ___define_initcall(fn, id, .initcall##id)

#define ___define_initcall(fn, id, __sec)			\
	__unique_initcall(fn, id, __sec, __initcall_id(fn))
	
#define __unique_initcall(fn, id, __sec, __iid)			\
	____define_initcall(fn,					\
		__initcall_stub(fn, __iid, id),			\
		__initcall_name(initcall, __iid, id),		\
		__initcall_section(__sec, __iid))

#define ____define_initcall(fn, __unused, __name, __sec)	\
	static initcall_t __name __used 			\
		__attribute__((__section__(__sec))) = fn;
		
#define __initcall_stub(fn, __iid, id)	fn

/* Format: __<prefix>__<iid><id> */
#define __initcall_name(prefix, __iid, id)			\
	__PASTE(__,						\
	__PASTE(prefix,						\
	__PASTE(__,						\
	__PASTE(__iid, id))))
	
#define __initcall_section(__sec, __iid)			\
	#__sec ".init"
		
#define __initcall_id(fn)					\
	__PASTE(__KBUILD_MODNAME,				\
	__PASTE(__,						\
	__PASTE(__COUNTER__,					\
	__PASTE(_,						\
	__PASTE(__LINE__,					\
	__PASTE(_, fn))))))
	
#define ___PASTE(a,b) a##b
#define __PASTE(a,b) ___PASTE(a,b)

static int __init omap_i2c_init_driver(void)

subsys_initcall(omap_i2c_init_driver);
static initcall_t __initcall__i2c-omap__(__COUNTER__)_(__LINE__)_omap_i2c_init_driver4 __used 			\
	__attribute__((__section__(__initcall__i2c-omap__(__COUNTER__)_(__LINE__)_omap_i2c_init_driver4))) = omap_i2c_init_driver;	

static initcall_t __initcall__partx __used 			\
	__attribute__((__section__(__initcall__partx))) = omap_i2c_init_driver;

----------------------------------------------------------------------------------------------------------
subsys_initcall(omap_i2c_init_driver);

#define subsys_initcall(omap_i2c_init_driver)		__define_initcall(omap_i2c_init_driver, 4)

#define __define_initcall(omap_i2c_init_driver, 4) ___define_initcall(omap_i2c_init_driver, 4, .initcall##4)

#define ___define_initcall(omap_i2c_init_driver, 4, .initcall4)			\
	__unique_initcall(omap_i2c_init_driver, 4, .initcall4, __initcall_id(omap_i2c_init_driver))
	=__unique_initcall(omap_i2c_init_driver, 4, .initcall4,i2c-omap__(__COUNTER__)_(__LINE__)_omap_i2c_init_driver)
	
#define __unique_initcall(fn, id, __sec, __iid)			\
	____define_initcall(omap_i2c_init_driver,					\
		__initcall_stub(omap_i2c_init_driver, i2c-omap__(__COUNTER__)_(__LINE__)_omap_i2c_init_driver, 4),			\
		__initcall_name(initcall, i2c-omap__(__COUNTER__)_(__LINE__)_omap_i2c_init_driver, 4),		\
		__initcall_section(.initcall4, i2c-omap__(__COUNTER__)_(__LINE__)_omap_i2c_init_driver))

#define ____define_initcall(fn, __unused, __name, __sec)	\
	static initcall_t __name __used 			\
		__attribute__((__section__(__sec))) = fn;
static initcall_t __initcall__i2c-omap__(__COUNTER__)_(__LINE__)_omap_i2c_init_driver4 __used 			\
	__attribute__((__section__(__initcall__i2c-omap__(__COUNTER__)_(__LINE__)_omap_i2c_init_driver4))) = omap_i2c_init_driver;	

static initcall_t __initcall__partx __used 			\
	__attribute__((__section__(__initcall__partx))) = omap_i2c_init_driver;
	
#define __initcall_stub(omap_i2c_init_driver, __iid, id)	
omap_i2c_init_driver

/* Format: __<prefix>__<iid><id> */
#define __initcall_name(prefix, __iid, id)			\
	__PASTE(__,						\
	__PASTE(prefix,						\
	__PASTE(__,						\
	__PASTE(__iid, id))))
__initcall__i2c-omap__(__COUNTER__)_(__LINE__)_omap_i2c_init_driver4
	
#define __initcall_section(__sec, __iid)			\
	#__sec ".init"
	.initcall4.init
		
#define __initcall_id(fn)					\
	__PASTE(__KBUILD_MODNAME,				\
	__PASTE(__,						\
	__PASTE(__COUNTER__,					\
	__PASTE(_,						\
	__PASTE(__LINE__,					\
	__PASTE(_, fn))))))
	
#define ___PASTE(a,b) a##b
#define __PASTE(a,b) ___PASTE(a,b)


#define __initcall_id(omap_i2c_init_driver)					\
	__PASTE(__KBUILD_MODNAME,				\
	__PASTE(__,						\
	__PASTE(__COUNTER__,					\
	__PASTE(_,						\
	__PASTE(__LINE__,					\
	__PASTE(_, omap_i2c_init_driver))))))
	
i2c-omap__(__COUNTER__)_(__LINE__)_omap_i2c_init_driver
=
CONFIG_HAVE_ARCH_PREL32_RELOCATIONS=n
CONFIG_LTO_CLANG=n

----------------------------------------------------------------------------------------------------------
asmlinkage __visible void __init __no_sanitize_address start_kernel(void)
	void __init __weak arch_call_rest_init(void)
		noinline void __ref rest_init(void)
			static int __ref kernel_init(void *unused)
				static noinline void __init kernel_init_freeable(void)
					static void __init do_basic_setup(void)
						static void __init do_initcalls(void)
							do_initcall_level(level, command_line);
								do_one_initcall(initcall_from_entry(fn));